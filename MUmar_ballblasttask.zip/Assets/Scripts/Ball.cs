using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Ball : MonoBehaviour
{
    private Rigidbody rbBall;
    private float JumpForce = 20;
    private float health = 5;
    public TMP_Text ballhealth;
    // Start is called before the first frame update
    void Start()
    {
       // healthUpdates();
    }

    // Update is called once per frame
    void Update()
    {
        healthUpdates();
    }

   
    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Bullet")
        {
            Damage(1);
            
        }
        if (collision.gameObject.tag == "ground")
        {
            rbBall.AddForce(Vector3.up * JumpForce, ForceMode.Impulse);
        }
        if(collision.gameObject.tag == "Player")
        {
            Debug.Log("Game Over");
        }
    }
    void Damage(int bl)
    {
        if(health > 1)
        {
            health -= bl;
        }else
        {
            ballDistroy();
        }
    }
    void ballDistroy()
    {
        Destroy(gameObject);
    }
    void healthUpdates()
    {
        ballhealth.text = health.ToString();
    }
}
