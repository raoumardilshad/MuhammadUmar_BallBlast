using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    public GameObject ballPrefab;
    private float spawnRangeX = 13;
    private float spawnRangeY = 10;
    private float startDelay = 1;
    private float TimeInterval = 4f;

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("SpawnBall", startDelay, TimeInterval);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void SpawnBall()
    {
        
        Vector3 spawnPos = new Vector3(Random.Range(-spawnRangeX, spawnRangeX), spawnRangeY, 0);
        Instantiate(ballPrefab, spawnPos, ballPrefab.transform.rotation);
    }
}
