using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyOutOfBound : MonoBehaviour
{
    private float TopBound = 15.0f;
    private float LowerBound = -1.0f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (transform.position.y > TopBound)
        {
            Destroy(gameObject);
        }
        else if (transform.position.y < LowerBound)
        {
            Destroy(gameObject);
        }
    }
}
